Built by Gabriel Dragffy
http://www.dragffy.com

Extension: APC
Version: 3.1.13
State: Beta
Release Date: 2012-09-03
Site: http://pecl.php.net/package/APC



Info:
I have not tested this build. Received some reports that it does not work, in that case I would
urge you to try one of my earlier build such as the build against PHP 5.4.4.
Built against PHP 5.4.8 on Windows 7 64bit Pro VC9.
Should work on 32bit Windows but untested.
This is a beta release of APC as it still does not work 100% with PHP 5.4


INSTALL

To install you need to copy php_apc.dll in to the php/ext directory. On my system, using XAMPP, I copied it to:
D:\xampp\php\ext

Copy the APC admin script "apc.php" in to a folder accessible to your webserver, in my case I copied it to:
D:\xampp\htdocs

View apc.php in your browser by going to e.g. http://localhost/apc.php, it should say "No cache info available. APC does not appear to be running."

Open up your php.ini file, on my system it is located at D:\xampp\php\php.ini
At the very bottom of the file append the following two lines:
apc.enabled=1
apc.stat=1

Save the file. Restart your web server (I clicked on STOP and then START in the XAMPP control panel). Next reload the APC admin script by visiting or refreshing http://localhost/apc.php you should see a stats page load up.